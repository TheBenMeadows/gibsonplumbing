<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<title>Gibson Plumbing</title>

		<link href="css/index.css" rel="stylesheet" type="text/css" />

		<link href="css/nav_bar_index.css" rel="stylesheet" type="text/css" />

		<script language="javascript" src = "_javascript/mm_css_menu.js" type="text/JavaScript"></script>

		<script language="javascript" src = "_javascript/_generic.js" type="text/JavaScript"></script>

		<meta name="google-site-verification"content="wKuRU9bO1fyLEpbLPFw0J3j3KQ91esWnKr77yfQIuWs" />

	</head>

	<body background="images/pipes-40.gif" >

		<div align="center">

			<div class="wrapper">

				<div class="main">

					<div class="top_space">&nbsp;

					</div>

					<div class="left_spacer">&nbsp;

					</div>

					<div class="nav">

						<div align="left">

<?php

 	include_once("inc/nav_bar_index.php");

?>						

<!--

								<a href="residential.php">Residential</a><br />

								<a href="commercial.php" >Commercial</a><br />

								<a href="home_owners.php" >Home Owners</a><br />						

								<a href="career_opportunities.htm" >Careers</a><br />

								<a href="about_us.php" >About Us</a> <br />

								<a href="contact_page.php" >Contacts</a><br /><br />

								<A href="javascript:void window.open('get_directions.htm', 'directions', 'height=300px, width= 450px')">

									Get Directions

								</A>

-->

						</div>

					</div>

				</div>

			</div>

		</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-18445742-1");
pageTracker._trackPageview();
} catch(err) {}</script>


	</body>

</html>

