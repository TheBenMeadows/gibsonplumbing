<?php

?>

		<div id="FWTableContainer1083977330">

<!--

nav_bar_index/

-->	

			<div class="nav_bar_row">

				<div class="nav_bar_item">

				   <a href="#" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer0913155748_0', 'MMMenu0913155748_0',125,0,'residential');MM_swapImage('residential','','nav_bar_index/residential_f2.gif',1);">

					   <img name="residential" src="nav_bar_index/residential.gif" width="164" height="19" border="0" id="residential" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

				   <img name="nav_bar_index_r2_c1" src="nav_bar_index/nav_bar_index_r2_c1.gif" width="164" height="15" border="0" id="nav_bar_index_r2_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="commercial.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('commercial','','nav_bar_index/commercial_f2.gif',1);">

					   <img name="commercial" src="nav_bar_index/commercial.gif" width="164" height="19" border="0" id="commercial" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

				   <img name="nav_bar_index_r4_c1" src="nav_bar_index/nav_bar_index_r4_c1.gif" width="164" height="15" border="0" id="nav_bar_index_r4_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="career_opportunities.htm" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('careers','','nav_bar_index/careers_f2.gif',1);">

					   <img name="careers" src="nav_bar_index/careers.gif" width="164" height="19" border="0" id="careers" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

				   <img name="nav_bar_index_r6_c1" src="nav_bar_index/nav_bar_index_r6_c1.gif" width="164" height="14" border="0" id="nav_bar_index_r6_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="about_us.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('about_us','','nav_bar_index/about_us_f2.gif',1);">

					   <img name="about_us" src="nav_bar_index/about_us.gif" width="164" height="19" border="0" id="about_us" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_index_r8_c1" src="nav_bar_index/nav_bar_index_r8_c1.gif" width="164" height="17" border="0" id="nav_bar_index_r8_c1" alt="" />

				</div>

 				<div class="nav_bar_item">

				   <a href="#" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer1003134734_1', 'MMMenu1003134734_1',164,0,'contacts');MM_swapImage('contacts','','nav_bar_index/contacts_f2.gif',1);">

					   <img name="contacts" src="nav_bar_index/contacts.gif" width="164" height="19" border="0" id="contacts" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_index_r8_c1" src="nav_bar_index/nav_bar_index_r8_c1.gif" width="164" height="17" border="0" id="nav_bar_index_r8_c1" alt="" />

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_index_r8_c1" src="nav_bar_index/nav_bar_index_r8_c1.gif" width="164" height="17" border="0" id="nav_bar_index_r8_c1" alt="" />

				</div>

				<div class="nav_bar_item">

					<a href="javascript:void window.open('get_directions.htm', 'directions', 'height=450px, width= 450px')" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('get_directions','','nav_bar_index/get_directions_f2.gif',1);">

						<img name="get_directions" src="nav_bar_index/get_directions.gif" width="164" height="19" border="0" id="get_directions" alt="" />

					</a>

				</div>

			</div>

			<div id="MMMenuContainer0913155748_0">

				<div id="MMMenu0913155748_0" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

					<a href="home_owners.php" target="_self" id="MMMenu0913155748_0_Item_0" class="MMMIFVStyleMMMenu0913155748_0" onmouseover="MM_menuOverMenuItem('MMMenu0913155748_0');">

						Home&nbsp;Owners

					</a>

					<a href="res_builders.php" target="_self" id="MMMenu0913155748_0_Item_1" class="MMMIVStyleMMMenu0913155748_0" onmouseover="MM_menuOverMenuItem('MMMenu0913155748_0');">

						Builders

					</a>

				</div>

			</div>

			<div id="MMMenuContainer1003134734_1">

				<div id="MMMenu1003134734_1" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

					<a href="contact_page.php?c=ho" target="_self" id="MMMenu1003134734_1_Item_0" class="MMMIFVStyleMMMenu1003134734_1" onmouseover="MM_menuOverMenuItem('MMMenu1003134734_1');">

						Home&nbsp;Owners

					</a>

					<a href="contact_page.php?c=rb" target="_self" id="MMMenu1003134734_1_Item_1" class="MMMIVStyleMMMenu1003134734_1" onmouseover="MM_menuOverMenuItem('MMMenu1003134734_1');">

						Residential&nbsp;Builders

					</a>

					<a href="contact_page.php?c=cc" target="_self" id="MMMenu1003134734_1_Item_2" class="MMMIVStyleMMMenu1003134734_1" onmouseover="MM_menuOverMenuItem('MMMenu1003134734_1');">

						Commercial&nbsp;Contractor

					</a>

				</div>

			</div>

		</div>

<!--

  <tr>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   </td>

 </tr>

  <tr>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   </td>

   <td>

   </td>

  </tr>

  <tr>

   <td>

   <td>

  </tr>

  <tr>

   <td>

   </td>

  </tr>

  <tr>

  </tr>

</table>

</div>



			<div id="MMMenuContainer0913113339_0">

				<div id="MMMenu0913113339_0" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

					<a href="home_owner.php" id="MMMenu0913113339_0_Item_0" class="MMMIFVStyleMMMenu0913113339_0" onmouseover="MM_menuOverMenuItem('MMMenu0913113339_0');">

						Home&nbsp;Owner

					</a>

					<a href="res_builder.php" id="MMMenu0913113339_0_Item_1" class="MMMIVStyleMMMenu0913113339_0" onmouseover="MM_menuOverMenuItem('MMMenu0913113339_0');">

						Builder

					</a>

				</div>

			</div>

		</div>

-->

