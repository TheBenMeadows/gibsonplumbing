<?php

?>

		<div id="FWTableContainer1970358823">

<!---->	

			<div class="nav_bar_row">

				<div class="nav_bar_item">

				   <a href="index.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('home','','nav_bar_vertical/home_f2.gif',1);">

					   <img name="home" src="nav_bar_vertical/home.gif" width="79" height="12" border="0" id="home" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					 <img name="nav_bar_r2_c1" src="nav_bar_vertical/nav_bar_r2_c1.gif" width="79" height="8" border="0" id="nav_bar_r2_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="javascript:;" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer0913152908_0', 'MMMenu0913152908_0',73,0,'residential');MM_swapImage('residential','','nav_bar_vertical/residential_f2.gif',1);">

					   <img name="residential" src="nav_bar_vertical/residential.gif" width="79" height="12" border="0" id="residential" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					 <img name="nav_bar_r2_c1" src="nav_bar_vertical/nav_bar_r2_c1.gif" width="79" height="8" border="0" id="nav_bar_r2_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="commercial.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('commercial','','nav_bar_vertical/commercial_f2.gif',1);">

					   <img name="commercial" src="nav_bar_vertical/commercial.gif" width="79" height="12" border="0" id="commercial" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					 <img name="nav_bar_r2_c1" src="nav_bar_vertical/nav_bar_r2_c1.gif" width="79" height="8" border="0" id="nav_bar_r2_c1" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="about_us.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('about_us','','nav_bar_vertical/about_us_f2.gif',1);">

					   <img name="about_us" src="nav_bar_vertical/about_us.gif" width="79" height="12" border="0" id="about_us" alt="" />

				   </a>

				</div>

<!--

	<div id="FWTableContainer1970358823">

		<table border="0" cellpadding="0" cellspacing="0" width="79">

			<tr>

				<td>

					<a href="index.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('home','','home_f2.gif',1);">

						<img name="home" src="home.gif" width="79" height="12" border="0" id="home" alt="" />

					</a>

				</td>

			</tr>

			<tr>

				<td>

					<img name="nav_bar_r2_c1" src="nav_bar_r2_c1.gif" width="79" height="8" border="0" id="nav_bar_r2_c1" alt="" />

				</td>

			</tr>

			<tr>

				<td>

					<a href="javascript:;" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer0913152908_0', 'MMMenu0913152908_0',73,0,'residential');MM_swapImage('residential','','residential_f2.gif',1);">

						<img name="residential" src="residential.gif" width="79" height="12" border="0" id="residential" alt="" />

					</a>

				</td>

			</tr>

			<tr>

				<td>

					<img name="nav_bar_r4_c1" src="nav_bar_r4_c1.gif" width="79" height="9" border="0" id="nav_bar_r4_c1" alt="" />

				</td>

			</tr>

			<tr>

				<td>

					<a href="commercial.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('commercial','','commercial_f2.gif',1);">

						<img name="commercial" src="commercial.gif" width="79" height="12" border="0" id="commercial" alt="" />

					</a>

				</td>

			</tr>

			<tr>

				<td>

					<img name="nav_bar_r6_c1" src="nav_bar_r6_c1.gif" width="79" height="7" border="0" id="nav_bar_r6_c1" alt="" />

				</td>

			</tr>

			<tr>

				<td>

					<a href="about_us.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('about_us','','about_us_f2.gif',1);">

						<img name="about_us" src="about_us.gif" width="79" height="12" border="0" id="about_us" alt="" />

					</a>

				</td>

			</tr>

		</table>

		<div id="MMMenuContainer0913152908_0">

			<div id="MMMenu0913152908_0" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

				<a href="home_owner.php" id="MMMenu0913152908_0_Item_0" class="MMMIFVStyleMMMenu0913152908_0" onmouseover="MM_menuOverMenuItem('MMMenu0913152908_0');">

					Home&nbsp;Owner

				</a>

				<a href="res_builder.php" id="MMMenu0913152908_0_Item_1" class="MMMIVStyleMMMenu0913152908_0" onmouseover="MM_menuOverMenuItem('MMMenu0913152908_0');">

					Builders

				</a>

			</div>

		</div>

	</div>

-->

				<div id="MMMenuContainer0913152908_0">

					<div id="MMMenu0913152908_0" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

						<a href="home_owner.php" id="MMMenu0913152908_0_Item_0" class="MMMIFVStyleMMMenu0913152908_0" onmouseover="MM_menuOverMenuItem('MMMenu0913152908_0');">

							Home&nbsp;Owner

						</a>

						<a href="res_builder.php" id="MMMenu0913152908_0_Item_1" class="MMMIVStyleMMMenu0913152908_0" onmouseover="MM_menuOverMenuItem('MMMenu0913152908_0');">

							Builders

						</a>

					</div>

				</div>

			</div>

		</div>



