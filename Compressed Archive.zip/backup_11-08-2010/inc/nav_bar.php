<?php

?>

		<div id="FWTableContainer1970358823">

<!---->	

			<div class="nav_bar_row">

				<div class="nav_bar_item">

					<a href="index.htm" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('Home','','nav_bar/Home_f2.gif',1);">

						<img name="Home" src="nav_bar/Home.gif" width="38" height="12" border="0" id="Home" alt="" />

					</a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_r1_c2" src="nav_bar/nav_bar_r1_c2.gif" width="19" height="12" border="0" id="nav_bar_r1_c2" alt="" />

				</div>

				<div class="nav_bar_item">

					<a href="residential.php" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer0913113339_0', 'MMMenu0913113339_0',68,6,'Residential');MM_swapImage('Residential','','nav_bar/Residential_f2.gif',1);">

						<img name="Residential" src="nav_bar/Residential.gif" width="73" height="12" border="0" id="Residential" alt="" />

					</a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_r1_c4" src="nav_bar/nav_bar_r1_c4.gif" width="22" height="12" border="0" id="nav_bar_r1_c4" alt="" />

				</div>

				<div class="nav_bar_item">

					<a href="commercial.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('commercial','','nav_bar/commercial_f2.gif',1);">

						<img name="commercial" src="nav_bar/commercial.gif" width="79" height="12" border="0" id="commercial" alt="" />

					</a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_r1_c6" src="nav_bar/nav_bar_r1_c6.gif" width="24" height="12" border="0" id="nav_bar_r1_c6" alt="" />

				</div>

				<div class="nav_bar_item">

					<a href="careers.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('careers','','nav_bar/careers_f2.gif',1);">

						<img name="careers" src="nav_bar/careers.gif" width="51" height="12" border="0" id="careers" alt="" />

					</a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_r1_c6" src="nav_bar/nav_bar_r1_c6.gif" width="24" height="12" border="0" id="nav_bar_r1_c6" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="about_us.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('about_us','','nav_bar/about_us_f2.gif',1);">

					   <img name="about_us" src="nav_bar/about_us.gif" width="62" height="12" border="0" id="about_us" alt="" />

				   </a>

				</div>

				<div class="nav_bar_item">

					<img name="nav_bar_r1_c8" src="nav_bar/nav_bar_r1_c6.gif" width="24" height="12" border="0" id="nav_bar_r1_c8" alt="" />

				</div>

				<div class="nav_bar_item">

				   <a href="contact_page.php" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('contacts','','nav_bar/contacts_f2.gif',1);">

					   <img name="contacts" src="nav_bar/contacts.gif" width="59" height="12" border="0" id="contacts" alt="" />

					</a>

				</div>

			</div>



<!--



	<table border="0" cellpadding="0" cellspacing="0" width="389">

		<tr>

		<td>

					<a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('Home','','nav_bar/Home_f2.gif',1);">

						<img name="Home" src="nav_bar/Home.gif" width="38" height="12" border="0" id="Home" alt="" />

					</a>

		</td>

		<td>

					<img name="nav_bar_r1_c2" src="nav_bar/nav_bar_r1_c2.gif" width="19" height="12" border="0" id="nav_bar_r1_c2" alt="" />

		</td>

		<td>

					<a href="javascript:;" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(100);" onmouseover="MM_menuShowMenu('MMMenuContainer0913113339_0', 'MMMenu0913113339_0',68,6,'Residential');MM_swapImage('Residential','','nav_bar/Residential_f2.gif',1);">

						<img name="Residential" src="nav_bar/Residential.gif" width="73" height="12" border="0" id="Residential" alt="" />

					</a>

		</td>

		<td>

		<img name="nav_bar_r1_c4" src="nav_bar_r1_c4.gif" width="22" height="12" border="0" id="nav_bar_r1_c4" alt="" />

		</td>

		<td><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('commercial','','commercial_f2.gif',1);"><img name="commercial" src="commercial.gif" width="79" height="12" border="0" id="commercial" alt="" /></a></td>

		<td><img name="nav_bar_r1_c6" src="nav_bar_r1_c6.gif" width="24" height="12" border="0" id="nav_bar_r1_c6" alt="" /></td>

		<td><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('careers','','careers_f2.gif',1);"><img name="careers" src="careers.gif" width="51" height="12" border="0" id="careers" alt="" /></a></td>

		<td><img name="nav_bar_r1_c8" src="nav_bar_r1_c8.gif" width="24" height="12" border="0" id="nav_bar_r1_c8" alt="" /></td>

		<td><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('contacts','','contacts_f2.gif',1);"><img name="contacts" src="contacts.gif" width="59" height="12" border="0" id="contacts" alt="" /></a></td>

		</tr>

	</table>

-->

			<div id="MMMenuContainer0913113339_0">

				<div id="MMMenu0913113339_0" onmouseout="MM_menuStartTimeout(100);" onmouseover="MM_menuResetTimeout();">

					<a href="home_owner.php" id="MMMenu0913113339_0_Item_0" class="MMMIFVStyleMMMenu0913113339_0" onmouseover="MM_menuOverMenuItem('MMMenu0913113339_0');">

						Home&nbsp;Owner

					</a>

					<a href="res_builder.php" id="MMMenu0913113339_0_Item_1" class="MMMIVStyleMMMenu0913113339_0" onmouseover="MM_menuOverMenuItem('MMMenu0913113339_0');">

						Builder

					</a>

				</div>

			</div>

		</div>



